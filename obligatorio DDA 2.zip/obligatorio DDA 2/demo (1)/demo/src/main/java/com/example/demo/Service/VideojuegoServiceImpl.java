package com.example.demo.Service;

import com.example.demo.Entity.VideojuegoEntity;
import com.example.demo.Entity.CategoriaEntity;
import com.example.demo.Exceptions.EntityNotFoundException;
import com.example.demo.Repository.VideojuegoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VideojuegoServiceImpl implements VideojuegoService {

    @Autowired
    private VideojuegoRepository videojuegoRepository;

    @Override
    public VideojuegoEntity guardarVideojuego(VideojuegoEntity videojuego) {
        return videojuegoRepository.save(videojuego);
    }

    @Override
    public VideojuegoEntity obtenerVideojuegoPorId(int id) {
        return videojuegoRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Videojuego no encontrado con id: " + id));
    }

    @Override
    public List<VideojuegoEntity> obtenerTodosLosVideojuegos() {

        return videojuegoRepository.findAll();
    }

    @Override
    public List<VideojuegoEntity> buscarPorCategoria(CategoriaEntity categoria) {
        return videojuegoRepository.findByCategoria(categoria);
    }

    @Override
    public List<VideojuegoEntity> buscarPorRangoDePrecios(double minPrecio, double maxPrecio) {
        return videojuegoRepository.findByPrecioBetween(minPrecio, maxPrecio);
    }

    @Override
    public List<VideojuegoEntity> buscarPorRangoDeStock(int minStock, int maxStock){
        return videojuegoRepository.findByStockBetween(minStock, maxStock);
    }

    @Override
    public List<VideojuegoEntity> buscarPorNombre(String nombre) {
        return videojuegoRepository.findByNombreContainingIgnoreCase(nombre);
    }

    @Override
    public void eliminarVideojuego(int id) {
        if (!videojuegoRepository.existsById(id)) {
            throw new EntityNotFoundException("Videojuego no encontrado con id: " + id);
        }
        videojuegoRepository.deleteById(id);
    }
}

