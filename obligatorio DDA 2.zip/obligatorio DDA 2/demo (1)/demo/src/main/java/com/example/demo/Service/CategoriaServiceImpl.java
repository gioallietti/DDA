package com.example.demo.Service;

import com.example.demo.Entity.CategoriaEntity;
import com.example.demo.Exceptions.EntityNotFoundException;
import com.example.demo.Repository.CategoriaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoriaServiceImpl implements CategoriaService {
    @Autowired
    private CategoriaRepository categoriaRepository;

    @Override
    public CategoriaEntity guardarCategoria(CategoriaEntity categoria) {
        return categoriaRepository.save(categoria);
    }

    @Override
    public CategoriaEntity obtenerCategoriaPorId(int id) {
        return categoriaRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Categoría no encontrada con id: " + id));
    }

    @Override
    public List<CategoriaEntity> obtenerTodasLasCategorias() {
        return categoriaRepository.findAll();
    }

    @Override
    public String eliminarCategoria(int id) {
        // Verificar si la categoria existe
        if (!categoriaRepository.existsById(id)) {
            throw new EntityNotFoundException("La categoria con id " + id + " no existe");
        }
        // Proceder a eliminar si existe
        categoriaRepository.deleteById(id);
        return "Categoria eliminado con éxito";
    }
}