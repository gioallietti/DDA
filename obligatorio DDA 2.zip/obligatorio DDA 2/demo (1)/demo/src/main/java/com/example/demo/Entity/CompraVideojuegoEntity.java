package com.example.demo.Entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;

@Entity
@Table(name = "compra_videojuego")
public class CompraVideojuegoEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne
    @JoinColumn(name = "compra_id", nullable = false)
    @JsonBackReference
    private CompraEntity compra;

    @ManyToOne
    @JoinColumn(name = "videojuego_codigo", nullable = false)
    private VideojuegoEntity videojuego;

    @Column(nullable = false)
    private int cantidad;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public CompraEntity getCompra() {
        return compra;
    }

    public void setCompra(CompraEntity compra) {
        this.compra = compra;
    }

    public VideojuegoEntity getVideojuego() {
        return videojuego;
    }

    public void setVideojuego(VideojuegoEntity videojuego) {
        this.videojuego = videojuego;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public CompraVideojuegoEntity(CompraEntity compra, VideojuegoEntity videojuego, int cantidad) {
        this.compra = compra;
        this.videojuego = videojuego;
        this.cantidad = cantidad;
    }

    public CompraVideojuegoEntity(){

    }
}
