    package com.example.demo.Entity;
    
    import com.fasterxml.jackson.annotation.JsonIgnore;
    import jakarta.persistence.*;
    import org.antlr.v4.runtime.misc.NotNull;

    import java.time.*;
    import java.util.*;
    
    @Entity
    @Table(name = "usuarios")
    public class UsuarioEntity {
    
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private int id;
    
        @Column(nullable = false)
        private String nombre;
    
        @Column(nullable = false, unique = true)
        private String email;
    
        @Column
        @NotNull
        private String contraseña;
    
        @Column(nullable = false)
        private LocalDate fechaRegistro;

        private boolean esPremium;
    
        @Column
        private LocalDate fechaMembresiaPremium;

        @Column(nullable = false)
        private boolean esAdministrador;

        @OneToMany(mappedBy = "usuario", cascade = CascadeType.ALL, orphanRemoval = true)
        @JsonIgnore // Ignorar la serialización de esta propiedad
        private List<CompraEntity> historialCompras;


        public int getId() {
            return id;
        }
    
        public void setId(int id) {
            this.id = id;
        }
    
        public String getNombre() {
            return nombre;
        }
    
        public void setNombre(String nombre) {
            this.nombre = nombre;
        }
    
        public String getEmail() {
            return email;
        }
    
        public void setEmail(String email) {
            this.email = email;
        }
    
        public String getContraseña(){
            return contraseña;
        }
    
        public void setContraseña(String contraseña){
            this.contraseña = contraseña;
        }
    
        public LocalDate getFechaRegistro() {
            return fechaRegistro;
        }
    
        public void setFechaRegistro(LocalDate fechaRegistro) {
            this.fechaRegistro = fechaRegistro;
        }
    
        public boolean isEsPremium() {
            return esPremium;
        }
    
        public void setEsPremium(boolean esPremium) {
            this.esPremium = esPremium;
        }
    
        public LocalDate getFechaMembresiaPremium() {
            return fechaMembresiaPremium;
        }
    
        public void setFechaMembresiaPremium(LocalDate fechaMembresiaPremium) {
            this.fechaMembresiaPremium = fechaMembresiaPremium;
        }

        public boolean isEsAdministrador() {
            return esAdministrador;
        }

        public void setEsAdministrador(boolean esAdministrador) {
            this.esAdministrador = esAdministrador;
        }
    
        public List<CompraEntity> getHistorialCompras() {
            return historialCompras;
        }

        public void setHistorialCompras(List<CompraEntity> historialCompras) {
            this.historialCompras = historialCompras;
        }

        public UsuarioEntity(String nombre, String email, String contraseña, LocalDate fechaRegistro, boolean esPremium, LocalDate fechaMembresiaPremium, boolean esAdministrador) {
            this.nombre = nombre;
            this.email = email;
            this.contraseña = contraseña;
            this.fechaRegistro = fechaRegistro;
            this.esPremium = esPremium;
            this.fechaMembresiaPremium = fechaMembresiaPremium;
            this.esAdministrador = esAdministrador;
        }
    
        public UsuarioEntity(){
    
        }
    }
