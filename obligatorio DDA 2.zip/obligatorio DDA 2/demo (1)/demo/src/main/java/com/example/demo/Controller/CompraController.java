package com.example.demo.Controller;

import com.example.demo.Entity.CompraEntity;
import com.example.demo.Entity.CompraVideojuegoEntity;
import com.example.demo.Service.CompraService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/compras")
public class CompraController {
    private final CompraService compraService;

    public CompraController(CompraService compraService) {
        this.compraService = compraService;
    }

    @PostMapping
    public ResponseEntity<CompraEntity> crearCompra(@RequestBody List<CompraVideojuegoEntity> videojuegosComprados, @RequestParam int usuarioId) {
        CompraEntity nuevaCompra = compraService.createCompra(usuarioId, videojuegosComprados);
        return ResponseEntity.status(HttpStatus.CREATED).body(nuevaCompra);
    }

    @GetMapping("/usuario/{usuarioId}")
    public ResponseEntity<List<CompraEntity>> listarComprasPorUsuario(@PathVariable int usuarioId) {
        List<CompraEntity> compras = compraService.listarComprasPorUsuario(usuarioId);
        return ResponseEntity.ok(compras);
    }

    @GetMapping("/fecha")
    public List<CompraEntity> listarComprasPorFecha(@RequestParam String fecha) {
        LocalDate fechaConsulta = LocalDate.parse(fecha);
        return compraService.listarComprasPorFecha(fechaConsulta);
    }

    @GetMapping("/todas")
    public ResponseEntity<?> listarCompras(){
        return ResponseEntity.status(HttpStatus.OK).body(compraService.listarTodasCompras());
    }
}
