package com.example.demo.Controller;

import com.example.demo.Entity.UsuarioEntity;
import com.example.demo.Exceptions.BadRequestException;
import com.example.demo.Service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.*;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/usuarios")
public class UsuarioController {
    @Autowired
    private UsuarioService usuarioService;

    @PostMapping("/CrearUsuarios")
    public ResponseEntity<?> agregarUsuario(@RequestBody Map<String, Object> requestData) {
        UsuarioEntity usuario = new UsuarioEntity();
        usuario.setNombre((String) requestData.get("nombre"));
        usuario.setEmail((String) requestData.get("email"));
        usuario.setEsPremium((Boolean) requestData.get("esPremium"));
        usuario.setContraseña((String) requestData.get("contraseña")); // Asegúrate de establecer la contraseña
        usuario.setEsAdministrador((Boolean) requestData.get("esAdministrador")); // Nuevo campo para administrador
        // Establecer la fecha de registro
        usuario.setFechaRegistro(LocalDate.now());

        if (usuario.isEsPremium()) {
            usuario.setFechaMembresiaPremium(LocalDate.now()); // Fecha actual para membresía premium
        }

        return ResponseEntity.status(HttpStatus.CREATED).body(usuarioService.guardarUsuario(usuario));
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> actualizarUsuario(@PathVariable int id, @RequestBody UsuarioEntity usuarioActualizado, @RequestParam int usuarioId) {
        UsuarioEntity usuario = usuarioService.obtenerUsuarioPorId(usuarioId); // Obtener el usuario por ID

        if (!usuario.isEsAdministrador()) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("No tienes permiso para realizar esta acción.");
        }

        UsuarioEntity usuarioExistente = usuarioService.obtenerUsuarioPorId(id);

        if (usuarioExistente == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Usuario no encontrado");
        }

        usuarioExistente.setNombre(usuarioActualizado.getNombre());
        usuarioExistente.setEmail(usuarioActualizado.getEmail());
        usuarioExistente.setEsPremium(usuarioActualizado.isEsPremium());

        if (usuarioActualizado.isEsPremium() && usuarioExistente.getFechaMembresiaPremium() == null) {
            usuarioExistente.setFechaMembresiaPremium(LocalDate.now());
        }

        return ResponseEntity.status(HttpStatus.OK).body(usuarioService.guardarUsuario(usuarioExistente));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminarUsuario(@PathVariable int id, @RequestParam int usuarioId) {
        UsuarioEntity usuario = usuarioService.obtenerUsuarioPorId(usuarioId); // Obtener el usuario por ID

        if (!usuario.isEsAdministrador()) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("No tienes permiso para realizar esta acción.");
        }

        return ResponseEntity.status(HttpStatus.OK).body(usuarioService.eliminarUsuario(id));
    }

    @GetMapping("/filtrar")
    public ResponseEntity<?> filtrarUsuarios(@RequestParam boolean esPremium, @RequestParam int usuarioId) {

        UsuarioEntity usuario = usuarioService.obtenerUsuarioPorId(usuarioId); // Obtener el usuario por ID

        if (!usuario.isEsAdministrador()) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("No tienes permiso para realizar esta acción.");
        }

        List<UsuarioEntity> usuarios = usuarioService.obtenerUsuariosPorTipo(esPremium);
        return ResponseEntity.status(HttpStatus.OK).body(usuarios);
    }

    @PostMapping("/login")
    public ResponseEntity<?> iniciarSesion(@RequestBody Map<String, String> requestData) {
        String email = requestData.get("email");
        String contraseña = requestData.get("contraseña");

        try {
            Map<String, Object> response = usuarioService.iniciarSesion(email, contraseña);
            return ResponseEntity.status(HttpStatus.OK).body(response);
        } catch (BadRequestException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    @GetMapping("/{id}/compras")
    public ResponseEntity<?> obtenerHistorialCompras(@PathVariable int id, @RequestParam int usuarioId ) {
        UsuarioEntity usuario = usuarioService.obtenerUsuarioPorId(usuarioId); // Obtener el usuario por ID

        if (!usuario.isEsAdministrador()) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("No tienes permiso para realizar esta acción.");
        }

        return ResponseEntity.status(HttpStatus.OK).body(usuarioService.obtenerHistorialCompras(id));
    }

    @GetMapping("/todos")
    public ResponseEntity<List<UsuarioEntity>> listarUsuarios() {
        List<UsuarioEntity> usuarios = usuarioService.listarUsuarios();
        return ResponseEntity.ok(usuarios);
    }

}
