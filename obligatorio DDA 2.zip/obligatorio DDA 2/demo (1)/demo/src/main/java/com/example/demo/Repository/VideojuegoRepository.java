package com.example.demo.Repository;

import com.example.demo.Entity.VideojuegoEntity;
import com.example.demo.Entity.CategoriaEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface VideojuegoRepository extends JpaRepository<VideojuegoEntity, Integer> {

    List<VideojuegoEntity> findByCategoria(CategoriaEntity categoria);

    List<VideojuegoEntity> findByPrecioBetween(double minPrecio, double maxPrecio);

    List<VideojuegoEntity> findByStockGreaterThan(int stock);

    List<VideojuegoEntity> findByNombreContainingIgnoreCase(String nombre);

    List<VideojuegoEntity> findByStockBetween(int minStock, int maxStock);
}
