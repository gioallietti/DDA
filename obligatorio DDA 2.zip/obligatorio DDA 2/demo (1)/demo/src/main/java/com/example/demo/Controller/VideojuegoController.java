package com.example.demo.Controller;

import com.example.demo.Entity.UsuarioEntity;
import com.example.demo.Entity.VideojuegoEntity;
import com.example.demo.Entity.CategoriaEntity;
import com.example.demo.Exceptions.EntityNotFoundException;
import com.example.demo.Repository.CategoriaRepository;
import com.example.demo.Service.UsuarioService;
import com.example.demo.Service.VideojuegoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.NoSuchElementException;

@RestController
@RequestMapping("/videojuegos")
@CrossOrigin(origins = "http://localhost:3000")
public class VideojuegoController {

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private VideojuegoService videojuegoService;

    @Autowired
    private CategoriaRepository categoriaRepository;

    @PostMapping("/crear")
    public ResponseEntity<?> crearVideojuego(@RequestBody VideojuegoEntity videojuego, @RequestParam int usuarioId) {
        try {
            UsuarioEntity usuario = usuarioService.obtenerUsuarioPorId(usuarioId);

            if (!usuario.isEsAdministrador()) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN).body("No tienes permiso para realizar esta acción.");
            }

            VideojuegoEntity nuevoVideojuego = videojuegoService.guardarVideojuego(videojuego);
            return ResponseEntity.status(HttpStatus.CREATED).body(nuevoVideojuego);
        } catch (NoSuchElementException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Usuario no encontrado.");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Ocurrió un error al crear el videojuego.");
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> obtenerVideojuego(@PathVariable int id) {
        return ResponseEntity.status(HttpStatus.OK).body(videojuegoService.obtenerVideojuegoPorId(id));
    }

    @GetMapping
    public ResponseEntity<?> listarVideojuegos() {
        return ResponseEntity.status(HttpStatus.OK).body(videojuegoService.obtenerTodosLosVideojuegos());
    }

    @GetMapping("/categoria/{idCategoria}")
    public ResponseEntity<?> buscarPorCategoria(@PathVariable int idCategoria) {
        CategoriaEntity categoria = categoriaRepository.findById(idCategoria)
                .orElseThrow(() -> new EntityNotFoundException("Categoría no encontrada"));
        return ResponseEntity.status(HttpStatus.OK).body(videojuegoService.buscarPorCategoria(categoria));
    }

    @GetMapping("/rango-precios")
    public ResponseEntity<?> buscarPorRangoDePrecios(@RequestParam double minPrecio, @RequestParam double maxPrecio) {
        return ResponseEntity.status(HttpStatus.OK).body(videojuegoService.buscarPorRangoDePrecios(minPrecio, maxPrecio));
    }

    @GetMapping("/rango-stock")
    public ResponseEntity<?> buscarPorRangoDeStock(@RequestParam int minStock, @RequestParam int maxStock) {
        if (minStock < 0 || maxStock <= 0 || minStock > maxStock) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("El rango de stock es inválido.");
        }
        return ResponseEntity.status(HttpStatus.OK).body(videojuegoService.buscarPorRangoDeStock(minStock, maxStock));
    }


    @GetMapping("/nombre")
    public ResponseEntity<?> buscarPorNombre(@RequestParam String nombre) {
        return ResponseEntity.status(HttpStatus.OK).body(videojuegoService.buscarPorNombre(nombre));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminarVideojuego(@PathVariable int id, @RequestParam int usuarioId) {
        UsuarioEntity usuario = usuarioService.obtenerUsuarioPorId(usuarioId); // Obtener el usuario por ID

        if (!usuario.isEsAdministrador()) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("No tienes permiso para realizar esta acción.");
        }

        videojuegoService.eliminarVideojuego(id);
        return ResponseEntity.status(HttpStatus.OK).body("Videojuego eliminado con éxito");
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> actualizarVideojuego(@PathVariable int id, @RequestBody VideojuegoEntity videojuegoActualizado, @RequestParam int usuarioId) {
        UsuarioEntity usuario = usuarioService.obtenerUsuarioPorId(usuarioId); // Obtener el usuario por ID

        if (!usuario.isEsAdministrador()) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("No tienes permiso para realizar esta acción.");
        }

        VideojuegoEntity videojuegoExistente = videojuegoService.obtenerVideojuegoPorId(id);

        if (videojuegoExistente == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("videojuego no encontrado");
        }

        videojuegoExistente.setNombre(videojuegoActualizado.getNombre());
        videojuegoExistente.setDescripcion(videojuegoActualizado.getDescripcion());
        videojuegoExistente.setPrecio(videojuegoActualizado.getPrecio());
        videojuegoExistente.setStock(videojuegoActualizado.getStock());
        videojuegoExistente.setImagen(videojuegoActualizado.getImagen());

        if (videojuegoActualizado.getCategoria() != null) {
            CategoriaEntity categoria = categoriaRepository.findById(videojuegoActualizado.getCategoria().getId())
                    .orElseThrow(() -> new EntityNotFoundException("Categoría no encontrada"));
            videojuegoExistente.setCategoria(categoria);
        }


        return ResponseEntity.status(HttpStatus.OK).body(videojuegoService.guardarVideojuego(videojuegoExistente));
    }
}
