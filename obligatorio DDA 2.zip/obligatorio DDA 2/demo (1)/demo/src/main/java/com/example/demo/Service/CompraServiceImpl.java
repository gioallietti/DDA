package com.example.demo.Service;

import com.example.demo.Entity.CompraEntity;
import com.example.demo.Entity.CompraVideojuegoEntity;
import com.example.demo.Entity.UsuarioEntity;
import com.example.demo.Entity.VideojuegoEntity;
import com.example.demo.Repository.CompraRepository;
import com.example.demo.Repository.CompraVideojuegoRepository;
import com.example.demo.Repository.UsuarioRepository;
import com.example.demo.Repository.VideojuegoRepository;
import com.example.demo.Exceptions.BadRequestException;
import com.example.demo.Exceptions.EntityNotFoundException;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.time.*;
import java.util.*;

@Service
public class CompraServiceImpl implements CompraService{
    private final CompraRepository compraRepository;
    private final UsuarioRepository usuarioRepository;
    private final VideojuegoRepository videojuegoRepository;
    private final CompraVideojuegoRepository compraVideojuegoRepository;

    public CompraServiceImpl(CompraRepository compraRepository, UsuarioRepository usuarioRepository, VideojuegoRepository videojuegoRepository, CompraVideojuegoRepository compraVideojuegoRepository) {
        this.compraRepository = compraRepository;
        this.usuarioRepository = usuarioRepository;
        this.videojuegoRepository = videojuegoRepository;
        this.compraVideojuegoRepository = compraVideojuegoRepository;
    }

    @Transactional
    @Override
    public CompraEntity createCompra(int usuarioId, List<CompraVideojuegoEntity> videojuegosComprados) {
        // 1. Validar el usuario
        UsuarioEntity usuario = usuarioRepository.findById(usuarioId)
                .orElseThrow(() -> new EntityNotFoundException("Usuario no encontrado"));

        // 2. Crear la nueva compra
        CompraEntity nuevaCompra = new CompraEntity();
        nuevaCompra.setUsuario(usuario);
        nuevaCompra.setFechaCompra(LocalDate.now());

        // 3. Calcular el total y verificar stock
        double total = 0;

        for (CompraVideojuegoEntity compraVideojuego : videojuegosComprados) {
            VideojuegoEntity videojuego = videojuegoRepository.findById(compraVideojuego.getVideojuego().getCodigo())
                    .orElseThrow(() -> new EntityNotFoundException("Videojuego no encontrado"));

            // Verificar stock
            if (videojuego.getStock() < compraVideojuego.getCantidad()) {
                throw new BadRequestException("No hay suficiente stock para el videojuego: " + videojuego.getNombre());
            }

            // Reducir el stock del videojuego
            videojuego.setStock(videojuego.getStock() - compraVideojuego.getCantidad());
            videojuegoRepository.save(videojuego);

            // Calcular el precio total
            double precioVideojuego = videojuego.getPrecio();
            total += precioVideojuego * compraVideojuego.getCantidad();

            // Establecer la relación de compra en cada CompraVideojuegoEntity
            compraVideojuego.setCompra(nuevaCompra); // Relación bidireccional
        }

        // 4. Aplicar descuento si el usuario es premium
        if (usuario.isEsPremium()) {
            total *= 0.80; // Aplicar un 20% de descuento
        }

        // 5. Establecer el total en la compra
        nuevaCompra.setTotal(total);

        // 6. Guardar la compra
        nuevaCompra = compraRepository.save(nuevaCompra);

        // 7. Guardar los videojuegos comprados
        for (CompraVideojuegoEntity compraVideojuego : videojuegosComprados) {
            compraVideojuegoRepository.save(compraVideojuego);
        }

        return nuevaCompra;
    }

    @Override
    public List<CompraEntity> listarComprasPorUsuario(int usuarioId) {
        // 1. Validar el usuario
        UsuarioEntity usuario = usuarioRepository.findById(usuarioId)
                .orElseThrow(() -> new EntityNotFoundException("Usuario no encontrado"));

        // 2. Obtener las compras del usuario
        List<CompraEntity> compras = compraRepository.findByUsuario(usuario);

        return compras;
    }

    @Override
    public List<CompraEntity> listarComprasPorFecha(LocalDate fecha) {
        return compraRepository.findByFechaCompra(fecha);
    }

    @Override
    public List<CompraEntity> listarTodasCompras(){
        return compraRepository.findAll();
    }
}
