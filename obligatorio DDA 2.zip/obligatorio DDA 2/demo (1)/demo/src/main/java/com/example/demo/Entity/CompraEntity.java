package com.example.demo.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "compras")
public class CompraEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne
    @JoinColumn(name = "usuario_id")
    @JsonIgnore
    private UsuarioEntity usuario;

    @Column(nullable = false)
    private LocalDate fechaCompra;

    @OneToMany(mappedBy = "compra", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<CompraVideojuegoEntity> videojuegosComprados;

    @Column(nullable = false)
    private double total;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public UsuarioEntity getUsuario() {
        return usuario;
    }

    public void setUsuario(UsuarioEntity usuario) {
        this.usuario = usuario;
    }

    public LocalDate getFechaCompra() {
        return fechaCompra;
    }

    public void setFechaCompra(LocalDate fechaCompra) {
        this.fechaCompra = fechaCompra;
    }

    public List<CompraVideojuegoEntity> getVideojuegosComprados() {
        return videojuegosComprados;
    }

    public void setVideojuegosComprados(List<CompraVideojuegoEntity> videojuegosComprados) {
        this.videojuegosComprados = videojuegosComprados;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public CompraEntity(UsuarioEntity usuario, LocalDate fechaCompra, List<CompraVideojuegoEntity> videojuegosComprados, double total) {
        this.usuario = usuario;
        this.fechaCompra = fechaCompra;
        this.videojuegosComprados = videojuegosComprados;
        this.total = total;
    }

    public CompraEntity(){

    }
}