package com.example.demo.Controller;

import com.example.demo.Entity.CategoriaEntity;
import com.example.demo.Service.CategoriaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/categorias")
public class CategoriaController {
    @Autowired
    private CategoriaService categoriaService;


    @PostMapping("/crea")
    public ResponseEntity<CategoriaEntity> agregarCategoria(@RequestBody CategoriaEntity categoria) {
        return ResponseEntity.status(HttpStatus.CREATED).body(categoriaService.guardarCategoria(categoria));
    }

    @GetMapping("/{id}")
    public ResponseEntity<CategoriaEntity> obtenerCategoria(@PathVariable int id) {
        return ResponseEntity.ok(categoriaService.obtenerCategoriaPorId(id));
    }


    @GetMapping("/todas")
    public ResponseEntity<List<CategoriaEntity>> listarCategorias() {
        return ResponseEntity.ok(categoriaService.obtenerTodasLasCategorias());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> eliminarCategoria(@PathVariable int id) {
        categoriaService.eliminarCategoria(id);
        return ResponseEntity.ok("Categoría eliminada con éxito.");
    }
}

