package com.example.demo.Repository;

import com.example.demo.Entity.UsuarioEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UsuarioRepository extends JpaRepository<UsuarioEntity, Integer> {
    UsuarioEntity findByEmail(String email);

    List<UsuarioEntity> findByEmailAndContraseña(String email, String contraseña);

    List<UsuarioEntity> findByEsPremium(boolean esPremium);

    boolean existsByEmail(String email);

}

