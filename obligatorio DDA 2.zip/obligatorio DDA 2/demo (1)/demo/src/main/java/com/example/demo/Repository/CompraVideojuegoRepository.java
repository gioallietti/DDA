package com.example.demo.Repository;

import com.example.demo.Entity.CompraVideojuegoEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CompraVideojuegoRepository extends JpaRepository<CompraVideojuegoEntity, Integer> {
}
