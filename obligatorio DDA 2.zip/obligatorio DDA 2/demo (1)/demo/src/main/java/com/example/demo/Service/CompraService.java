package com.example.demo.Service;

import com.example.demo.Entity.CompraEntity;
import com.example.demo.Entity.CompraVideojuegoEntity;

import java.time.LocalDate;
import java.util.*;

public interface CompraService {
    CompraEntity createCompra(int usuarioId, List<CompraVideojuegoEntity> videojuegosComprados);
    List<CompraEntity> listarComprasPorUsuario(int usuarioId);
    List<CompraEntity> listarComprasPorFecha (LocalDate fecha);
    List<CompraEntity> listarTodasCompras();
}
