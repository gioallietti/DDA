package com.example.demo.Service;

import com.example.demo.Entity.CompraEntity;
import com.example.demo.Entity.UsuarioEntity;
import com.example.demo.Exceptions.EntityNotFoundException;
import com.example.demo.Repository.UsuarioRepository;
import com.example.demo.Exceptions.BadRequestException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class UsuarioServiceImpl implements UsuarioService {
    @Autowired
    private UsuarioRepository usuarioRepository;

    @Override
    public UsuarioEntity guardarUsuario(UsuarioEntity usuarioEntity) {
        try {
            // Verificar si el email ya existe
            if (usuarioRepository.existsByEmail(usuarioEntity.getEmail())) {
                throw new BadRequestException("El email ya está en uso.");
            }
            // Establecer la fecha de registro
            usuarioEntity.setFechaRegistro(LocalDate.now());
            if (usuarioEntity.isEsPremium()) {
                usuarioEntity.setFechaMembresiaPremium(LocalDate.now());
            }
            // Guardar el usuario
            return usuarioRepository.save(usuarioEntity);
        } catch (Exception ex) {
            throw new BadRequestException("Error al guardar el usuario: " + ex.getMessage());
        }
    }

    @Override
    public String eliminarUsuario(int id) {
        // Verificar si el usuario existe
        if (!usuarioRepository.existsById(id)) {
            throw new EntityNotFoundException("El usuario con id " + id + " no existe");
        }
        // Proceder a eliminar si existe
        usuarioRepository.deleteById(id);
        return "Usuario eliminado con éxito";
    }

    @Override
    public Map<String, Object> iniciarSesion(String email, String contraseña) {
        Optional<UsuarioEntity> usuario = usuarioRepository.findByEmailAndContraseña(email, contraseña).stream().findFirst();
        if (usuario.isPresent()) {
            Map<String, Object> response = new HashMap<>();
            response.put("message", "Se inició sesión con éxito");
            response.put("usuarioId", usuario.get().getId());
            return response;
        }
        throw new BadRequestException("Credenciales incorrectas");
    }

    @Override
    public UsuarioEntity obtenerUsuarioPorId(int id) {
        return usuarioRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Usuario no encontrado con id: " + id));
    }

    @Override
    public List<UsuarioEntity> obtenerUsuariosPorTipo(boolean esPremium) {
        return usuarioRepository.findByEsPremium(esPremium);
    }

    @Override
    public UsuarioEntity obtenerUsuarioPorEmail(String email) {
        UsuarioEntity usuario = usuarioRepository.findByEmail(email);
        if (usuario == null) {
            throw new EntityNotFoundException("Usuario no encontrado con email: " + email);
        }
        return usuario;
    }

    @Override
    public List<CompraEntity> obtenerHistorialCompras(int idUsuario) {
        UsuarioEntity usuario = obtenerUsuarioPorId(idUsuario);
        return usuario.getHistorialCompras();
    }

    @Override
    public List<UsuarioEntity> listarUsuarios() {
        return usuarioRepository.findAll();
    }

}
