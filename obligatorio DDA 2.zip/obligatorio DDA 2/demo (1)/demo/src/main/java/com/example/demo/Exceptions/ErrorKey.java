package com.example.demo.Exceptions;

public enum ErrorKey {
    NOT_FOUND,
    BAD_REQUEST,
}
