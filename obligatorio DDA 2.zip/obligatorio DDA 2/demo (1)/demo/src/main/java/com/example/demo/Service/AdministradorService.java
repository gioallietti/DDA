package com.example.demo.Service;

public interface AdministradorService {
}
