package com.example.demo.Service;

public class AdministradorServiceImpl {
}
