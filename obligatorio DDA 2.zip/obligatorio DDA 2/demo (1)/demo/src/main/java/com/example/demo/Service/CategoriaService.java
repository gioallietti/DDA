package com.example.demo.Service;

import com.example.demo.Entity.CategoriaEntity;

import java.util.List;

public interface CategoriaService {
    CategoriaEntity guardarCategoria(CategoriaEntity categoria);
    CategoriaEntity obtenerCategoriaPorId(int id);
    List<CategoriaEntity> obtenerTodasLasCategorias();
    String eliminarCategoria(int id);
}
