package com.example.demo.Service;

import com.example.demo.Entity.VideojuegoEntity;
import com.example.demo.Entity.CategoriaEntity;
import java.util.List;

public interface VideojuegoService {
    VideojuegoEntity guardarVideojuego(VideojuegoEntity videojuego);
    VideojuegoEntity obtenerVideojuegoPorId(int id);
    List<VideojuegoEntity> obtenerTodosLosVideojuegos();
    List<VideojuegoEntity> buscarPorCategoria(CategoriaEntity categoria);
    List<VideojuegoEntity> buscarPorRangoDePrecios(double minPrecio, double maxPrecio);
    List<VideojuegoEntity> buscarPorRangoDeStock(int minStock, int maxStock);
    List<VideojuegoEntity> buscarPorNombre(String nombre);
    void eliminarVideojuego(int id);
}
