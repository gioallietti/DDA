package com.example.demo.Controller;

import com.example.demo.Entity.VideojuegoEntity;
import com.example.demo.Service.VideojuegoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/administrador")
@CrossOrigin(origins = "http://localhost:3000")
public class AdministradorController {

    @Autowired
    private VideojuegoService videojuegoService;

    @PostMapping("/crear")
    public ResponseEntity<?> crearVideojuego(@RequestBody VideojuegoEntity videojuego) {
        return ResponseEntity.status(HttpStatus.CREATED).body(videojuegoService.guardarVideojuego(videojuego));
    }
}
