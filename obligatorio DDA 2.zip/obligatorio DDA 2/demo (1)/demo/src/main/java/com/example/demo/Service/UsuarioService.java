package com.example.demo.Service;

import com.example.demo.Entity.CompraEntity;
import com.example.demo.Entity.UsuarioEntity;

import java.util.*;

public interface UsuarioService {
    UsuarioEntity guardarUsuario(UsuarioEntity usuarioEntity);
    String eliminarUsuario(int id);
    UsuarioEntity obtenerUsuarioPorId(int id);
    UsuarioEntity obtenerUsuarioPorEmail(String email);
    List<UsuarioEntity> obtenerUsuariosPorTipo(boolean esPremium);
    Map<String, Object> iniciarSesion(String email, String contraseña);
    List<CompraEntity> obtenerHistorialCompras(int idUsuario);
    List<UsuarioEntity> listarUsuarios ();
}
