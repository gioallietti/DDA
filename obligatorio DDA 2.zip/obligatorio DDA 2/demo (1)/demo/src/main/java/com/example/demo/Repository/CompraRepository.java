package com.example.demo.Repository;

import com.example.demo.Entity.CompraEntity;
import com.example.demo.Entity.UsuarioEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface CompraRepository extends JpaRepository<CompraEntity, Integer> {
    List<CompraEntity> findByUsuario(UsuarioEntity usuario);
    List<CompraEntity> findByFechaCompra(LocalDate fecha);
}
